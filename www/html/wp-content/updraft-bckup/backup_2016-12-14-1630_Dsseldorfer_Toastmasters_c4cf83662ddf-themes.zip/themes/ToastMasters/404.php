<?php get_header(); ?>
<!-- start left sidebar -->
<?php include("leftsidebar.php"); ?>
<!-- end leftsidebar  -->
	<div class="contentmain">
	<div id="content" class="narrowcolumn">
<center><h2 class="title">Error 404 - Page Not Found</h2></center>
</div>
</div>
<?php //get_sidebar(); ?>
<?php get_footer(); ?>